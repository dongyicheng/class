<template>
  <div class="book_box">
    <img src="https://img13.360buyimg.com/n1/s200x200_jfs/t5107/58/1653926146/128683/79be7ee8/5912e2fcNf9a839fc.jpg" alt="">
    <p>node.js</p>
  </div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>

</style>
