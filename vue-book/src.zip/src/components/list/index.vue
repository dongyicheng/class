<template>
    <div>
      列表页
    </div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>

</style>
