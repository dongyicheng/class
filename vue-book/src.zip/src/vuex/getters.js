export const evenCount = state => state.count%2 ? state.count :'奇数' ;
