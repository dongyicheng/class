//存储数据用的
const state = {
  count:0,
  bannerData:[]
};
export {state}
// export default state
